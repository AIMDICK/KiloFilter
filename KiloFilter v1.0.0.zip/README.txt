================================================================================
                        KILOFILTER - VERSIONS GUIDE
================================================================================

REPOSITORY: https://github.com/AIMDICK/KiloFilter/

================================================================================
                           WHICH VERSION TO USE?
================================================================================

1. STANDALONE (Recommended for most users)
   └─ KiloFilter.exe (155.29 MB)
   
   ✓ Complete and ready to use
   ✓ No additional installation required
   ✓ No .NET Runtime needed
   ✓ Single executable file
   ✓ Works on any Windows system
   
   → Use this if you want the easiest, most straightforward experience

================================================================================

2. LIGHTWEIGHT (For advanced users with .NET 8)
   └─ KiloFilter files (1.08 MB total)
   
   ✓ Much smaller file size
   ✓ Requires .NET 8 Runtime to be installed
   ✓ Multiple files (proper deployment)
   ✓ Better for development environments
   
   → Use this if:
      - You already have .NET 8 Runtime installed
      - You want to minimize disk space
      - You prefer a proper folder structure

   Download .NET 8: https://dotnet.microsoft.com/download/dotnet/8.0

================================================================================
                              QUICK START
================================================================================

For Standalone:
  1. Extract KiloFilter.exe from the Standalone folder
  2. Double-click to run
  3. Done!

For Lightweight:
  1. Ensure .NET 8 Runtime is installed
  2. Extract all files from the Lightweight folder
  3. Run KiloFilter.exe
  4. Done!

================================================================================
                            SYSTEM REQUIREMENTS
================================================================================

Standalone:
  - Windows 7 or later (32/64-bit)
  - No additional software required

Lightweight:
  - Windows 7 or later (32/64-bit)
  - .NET 8 Runtime (download from: https://dotnet.microsoft.com/download/)

================================================================================
                              FILE LOCATIONS
================================================================================

Repository:  https://github.com/AIMDICK/KiloFilter/
Issues:      https://github.com/AIMDICK/KiloFilter/issues
Releases:    https://github.com/AIMDICK/KiloFilter/releases

================================================================================
                                  NOTES
================================================================================

- Both versions have identical functionality
- Neither version modifies system files
- All operations are reversible (original files are never deleted unless you explicitly choose to)
- For bug reports or feature requests, visit the GitHub repository

================================================================================
                              SUPPORT & INFO
================================================================================

For more information, documentation, and support, visit:
https://github.com/AIMDICK/KiloFilter/

================================================================================
